Page({
  data: {
    imgUrls: [
      '/images/timg1.jpg',
      '/images/timg2.jpg',
      '/images/timg3.jpg',
      '/images/timg4.jpg'
    ]
  }
})